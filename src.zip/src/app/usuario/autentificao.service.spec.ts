import { TestBed } from '@angular/core/testing';

import { AutentificaoService } from './autentificao.service';

describe('AutentificaoService', () => {
  let service: AutentificaoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AutentificaoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
