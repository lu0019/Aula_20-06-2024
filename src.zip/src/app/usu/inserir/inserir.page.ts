import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inserir',
  templateUrl: './inserir.page.html',
  styleUrls: ['./inserir.page.scss'],
})
export class InserirPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
